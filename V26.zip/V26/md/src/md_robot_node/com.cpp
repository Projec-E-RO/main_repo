///////////////////////////
// com.cpp

#include "md_robot_node/global.hpp"
#include "md_robot_node/main.hpp"
#include "md_robot_node/com.hpp"

#define MD_PROTOCOL_POS_PID             3
#define MD_PROTOCOL_POS_DATA_LEN        4
#define MD_PROTOCOL_POS_DATA_START      5

#define ENABLE_SERIAL_DEBUG             0

serial::Serial ser;

PID_PNT_MAIN_DATA_t curr_pid_pnt_main_data;
PID_IO_MONITOR_t curr_pid_io_monitor;
PID_ROBOT_MONITOR_t curr_pid_robot_monitor;
PID_ROBOT_MONITOR2_t curr_pid_robot_monitor2;

uint8_t serial_comm_rcv_buff[MAX_PACKET_SIZE];
uint8_t serial_comm_snd_buff[MAX_PACKET_SIZE];

extern uint32_t pid_response_receive_count;
extern uint32_t pid_request_cmd_vel_count;
extern INIT_SETTING_STATE_t fgInitsetting;
extern void MakeMDRobotMessage1(PID_PNT_MAIN_DATA_t *pData);
extern void MakeMDRobotMessage2(PID_ROBOT_MONITOR_t *pData);
extern void PubRobotOdomMessage(void);
extern void PubRobotRPMMessage(void);

extern std::string serial_port;

//Initialize serial communication in ROS
int InitSerialComm(void)
{
    std::string port;

    port = "/dev/" + serial_port;
    ROS_INFO("Serial port: %s", port.c_str());
    ROS_INFO("Serial baudrate: %d", robotParamData.nBaudrate);

    try
    {
        ser.setPort(port);
        ser.setBaudrate(robotParamData.nBaudrate);
        serial::Timeout to = serial::Timeout::simpleTimeout(1667); //1667 when baud is 57600, 0.6ms
        ser.setTimeout(to);                                        //2857 when baud is 115200, 0.35ms
        ser.open();
    }

    catch (serial::IOException& e)
    {
        printf("\r\n");
        ROS_ERROR_STREAM("Unable to open port\r\n");
        return -1;
    }

    if(ser.isOpen()) {
        printf("\r\n");
        ROS_INFO_STREAM("*Serial port open succes!\r\n");
        //PutMdData(PID_ALARM_LOG, robotParamData.nIDMDT, nullptr, 0);
        return 1;
    }
    else {
        return -1;
    }
}
uint16_t CalCheckSum(uint8_t *pData, uint16_t length)
{
    uint16_t sum;

    sum = 0;
    for(int i = 0; i < length; i++) {
        sum += *pData++;
    }

    sum = ~sum + 1; //check sum

    return sum;
}
/*
uint8_t CalCheckSum(uint8_t *pData, uint16_t length)
{
    uint16_t sum;

    sum = 0;
    for(int i = 0; i < length; i++) {
        sum += *pData++;
    }

    sum = ~sum + 1; //check sum

    return sum;
}
*/
int PutMdData(PID_CMD_t pid, uint16_t rmid, const uint8_t *pData, uint16_t length)
{
    uint8_t *p;
    uint16_t len;

    len = 0;
    serial_comm_snd_buff[len++] = rmid;
    serial_comm_snd_buff[len++] = robotParamData.nIDPC;
    serial_comm_snd_buff[len++] = 1;
    serial_comm_snd_buff[len++] = (uint8_t)pid;
    serial_comm_snd_buff[len++] = length;

    p = (uint8_t *)&serial_comm_snd_buff[len];
    memcpy((char *)p, (char *)pData, length);
    len += length;

    serial_comm_snd_buff[len++] = CalCheckSum(serial_comm_snd_buff, len);

    if(ser.isOpen() == true) {
        ser.write(serial_comm_snd_buff, len);
        // 3) 두 번째 드라이버 ID가 유효하면, 앞바이트(rmid)만 바꿔서 재전송
        uint16_t second = robotParamData.nIDMDT2;
        if (second != 0 && second != rmid) {
            uint8_t orig = serial_comm_snd_buff[0];
            serial_comm_snd_buff[0] = (uint8_t)second;
            // 체크섬 재계산 (마지막 바이트만)
            serial_comm_snd_buff[len-1] = CalCheckSum(serial_comm_snd_buff, len-1);
            ser.write(serial_comm_snd_buff, len);
            // 복원 (혹시 디버깅 등 나중에 원본이 필요하면)
            serial_comm_snd_buff[0] = orig;
        }
        
    }

    return 1;
} 
// 새로운 PutMdDataPerID: 지정 ID에만 전송
// 새로운 PutMdDataPerID: 지정된 IDParameter로만 전송
int PutMdDataPerID(PID_CMD_t pid, uint8_t idParam, const uint8_t *pData, uint16_t length)
{
    uint8_t buf[MAX_PACKET_SIZE];
    uint16_t len = 0;
    // Header: RMID, PC ID, IDParameter, PID, Data length
    buf[len++] = (uint8_t)robotParamData.nRMID;    // 183 (공통)
    buf[len++] = (uint8_t)robotParamData.nIDPC;    // TMID (PC ID)
    buf[len++] = idParam;                         // IDParameter (1 또는 20)
    buf[len++] = (uint8_t)pid;                    // 명령 코드 (207)
    buf[len++] = (uint8_t)length;                 // 데이터 길이 (7)
    // Payload 복사
    memcpy(&buf[len], pData, length);
    len += length;
    // Checksum 계산 및 추가
    buf[len++] = (uint8_t)CalCheckSum(buf, len);
    // 직렬 포트에 전송
    if (ser.isOpen()) {
        ser.write(buf, len);
    }
    return 1;
}

int MdReceiveProc(void) //save the identified serial data to defined variable according to PID NUMBER data
{
    uint8_t *pRcvBuf = serial_comm_rcv_buff;
    uint8_t drv_id   = pRcvBuf[2];      // [0]=PC ID, [1]=송신장치 ID [2]=모터드라이버 ID
    uint8_t *pRcvData;
    uint8_t byRcvPID;
    uint8_t byRcvDataSize;
    static bool got_motor12 = false;
    static bool got_motor34 = false;

    byRcvPID      = pRcvBuf[MD_PROTOCOL_POS_PID];
    byRcvDataSize = pRcvBuf[MD_PROTOCOL_POS_DATA_LEN];
    pRcvData      = &pRcvBuf[MD_PROTOCOL_POS_DATA_START];
    ROS_INFO("← RCV pid=%u from drv %u", pRcvBuf[MD_PROTOCOL_POS_PID], drv_id);
    switch(byRcvPID)
    {
        case PID_IO_MONITOR:                // 194
        {
            ROS_INFO("RCV: PID_IO_MONITOR: %d, %d", byRcvDataSize, (int)sizeof(PID_IO_MONITOR_t));
            memcpy((char *)&curr_pid_io_monitor, (char *)pRcvData, sizeof(PID_PNT_MAIN_DATA_t));
            ROS_INFO("Inout voltage: %d", curr_pid_io_monitor.input_voltage);
            break;
        }

        case PID_ROBOT_MONITOR2: // mduI 전용
        {
            ROS_INFO("RCV: PID_ROBOT_MONITOR2: %d, %d", byRcvDataSize, (int)sizeof(PID_ROBOT_MONITOR2_t));
            memcpy((char *)&curr_pid_robot_monitor2, (char *)pRcvData, sizeof(PID_ROBOT_MONITOR2_t));
            ROS_INFO("Inout voltage: %d", curr_pid_robot_monitor2.sVoltIn);
            break;
        }

        case PID_PNT_MAIN_DATA: // 210
        {
            if (byRcvDataSize == sizeof(PID_PNT_MAIN_DATA_t)) {
                pid_response_receive_count++;
                pid_request_cmd_vel_count = 2;

                // 일단 임시 구조체로 복사
                PID_PNT_MAIN_DATA_t tmp;
                memcpy(&tmp, pRcvData, sizeof(tmp));
                ROS_INFO("[DEBUG] drv_id = %u", drv_id);
                ROS_INFO("[DEBUG] tmp.mtr_pos_id1 = %d, rpm1 = %d, state1 = %u", tmp.mtr_pos_id1, tmp.rpm_id1, tmp.mtr_state_id1.val);
                ROS_INFO("[DEBUG] tmp.mtr_pos_id2 = %d, rpm2 = %d, state2 = %u", tmp.mtr_pos_id2, tmp.rpm_id2, tmp.mtr_state_id2.val);
                // 드라이버 ID에 따라 curr_pid_pnt_main_data의 적절한 필드에 복사
                if (drv_id == robotParamData.nid) {
                    // 첫 번째 드라이버 (ID=1) → motor1/motor2
                    curr_pid_pnt_main_data.mtr_pos_id1   = tmp.mtr_pos_id1;
                    curr_pid_pnt_main_data.rpm_id1       = tmp.rpm_id1;
                    curr_pid_pnt_main_data.mtr_state_id1 = tmp.mtr_state_id1.val;
                    curr_pid_pnt_main_data.mtr_pos_id2   = tmp.mtr_pos_id2;
                    curr_pid_pnt_main_data.rpm_id2       = tmp.rpm_id2;
                    curr_pid_pnt_main_data.mtr_state_id2 = tmp.mtr_state_id2.val;
                    got_motor12 = true;
                    ROS_INFO("[Drv%u] Got PNT_MAIN_DATA (1/2)", drv_id);
                }
                else if (drv_id == robotParamData.nid2) {
                    // 두 번째 드라이버 (ID=20) → motor3/motor4
                    // motor3 → curr_pid_pnt_main_data.mtr_pos_id3 같은 필드가 없으면
                    // 예를 들어 mtr_pos_id2 뒤에 3,4를 추가한 뒤 아래처럼 복사하세요.
                    curr_pid_pnt_main_data.mtr_pos_id3   = tmp.mtr_pos_id1;
                    curr_pid_pnt_main_data.rpm_id3       = tmp.rpm_id1;
                    curr_pid_pnt_main_data.mtr_state_id3 = tmp.mtr_state_id1.val;
                    curr_pid_pnt_main_data.mtr_pos_id4   = tmp.mtr_pos_id2;
                    curr_pid_pnt_main_data.rpm_id4       = tmp.rpm_id2;
                    curr_pid_pnt_main_data.mtr_state_id4 = tmp.mtr_state_id2.val;
                    got_motor34 = true;
                    ROS_INFO("[Drv%u] Got PNT_MAIN_DATA (3/4)", drv_id);
                }

                // 필요한 디버깅 정보
                ROS_INFO("  drv%u pos: %d,%d  rpm: %d,%d",
                         drv_id,
                         tmp.mtr_pos_id1, tmp.mtr_pos_id2,
                         tmp.rpm_id1,     tmp.rpm_id2);

                if (got_motor12 && got_motor34) {
                    MakeMDRobotMessage1(&curr_pid_pnt_main_data);
                    PubRobotRPMMessage();
                    got_motor12 = false;
                    got_motor34 = false;
                }
            }
            break;
        } 

        case PID_ROBOT_MONITOR:        // 253
        {
            if(byRcvDataSize == sizeof(PID_ROBOT_MONITOR_t)) {
                // ROS_INFO("RCV: PID_ROBOT_MONITOR_t: %d, %d", byRcvDataSize, (int)sizeof(PID_ROBOT_MONITOR_t));

                pid_response_receive_count++;
                pid_request_cmd_vel_count = 2;

                memcpy((char *)&curr_pid_robot_monitor, (char *)pRcvData, sizeof(PID_ROBOT_MONITOR_t));
#if 1
                ROS_INFO("%d", curr_pid_robot_monitor.lTempPosi_x);
                ROS_INFO("%d", curr_pid_robot_monitor.lTempPosi_y);
                ROS_INFO("%d", curr_pid_robot_monitor.sTempTheta);
                ROS_INFO("%d", curr_pid_robot_monitor.battery_percent);
                ROS_INFO("%d", curr_pid_robot_monitor.byUS1);
                ROS_INFO("%d", curr_pid_robot_monitor.byUS2);
                ROS_INFO("%d", curr_pid_robot_monitor.byUS3);
                ROS_INFO("%d", curr_pid_robot_monitor.byUS4);
                ROS_INFO("0x%x", (uint8_t)curr_pid_robot_monitor.byPlatStatus.val);
                ROS_INFO("%d", curr_pid_robot_monitor.linear_velocity);
                ROS_INFO("%d", curr_pid_robot_monitor.angular_velocity);
                ROS_INFO(" ");
#endif                

                if(robotParamData.use_MDUI == 1) {  // If using MDUI
                    MakeMDRobotMessage2(&curr_pid_robot_monitor);

                    PubRobotOdomMessage();
                }
            }
            break;
        }

        case PID_ROBOT_PARAM:  // 247
        {
            // ROS_INFO("RCV: PID_ROBOT_PARAM: %d, %d", byRcvDataSize, (int)sizeof(PID_ROBOT_PARAM_t));
            if(byRcvDataSize == sizeof(PID_ROBOT_PARAM_t)) {
                PID_ROBOT_PARAM_t *p;

                p = (PID_ROBOT_PARAM_t *)pRcvData;
#if 0
                ROS_INFO("Diameter: %d", p->nDiameter);
                ROS_INFO("Wheel Length: %d", p->nWheelLength);
                ROS_INFO("Gear Ratio: %d", p->nGearRatio);
#endif                
            }
            break;
        }

        default:
            break;
    }
    return 1;
}

int AnalyzeReceivedData(uint8_t byArray[], uint8_t byBufNum) //Analyze the communication data
{
    ros::NodeHandle n;
    ros::Time stamp;
    uint8_t i, j;
    uint8_t data;
    static uint8_t byChkSec;
    static long lExStampSec, lExStampNsec;
    static uint32_t byPacketNum;
    static uint32_t rcv_step;
    static uint8_t byChkSum;
    static uint16_t byMaxDataNum;
    static uint16_t byDataNum;

    if(byPacketNum >= MAX_PACKET_SIZE)
    {
        rcv_step = 0;
        byPacketNum = 0;

        return 0;
    }
    
    for(j = 0; j < byBufNum; j++)
    {
        data = byArray[j];
#if (ENABLE_SERIAL_DEBUG == 1)
        printf("%02x(%3d) ", data, data);
#endif
        switch(rcv_step) {
            case 0:    //Put the reading machin id after checking the data
                if(data == robotParamData.nIDPC)
                {
                    byPacketNum = 0;
                    byChkSum = data;
                    serial_comm_rcv_buff[byPacketNum++] = data;

                    rcv_step++;
                }
                else
                {
                    byPacketNum = 0;
#if (ENABLE_SERIAL_DEBUG == 1)                    
                    ROS_INFO("received ID: %d(0x%02x)", data, data);
                    ROS_INFO("error.ser: %s, %d", __FILE__, __LINE__);
#endif
                }
                break;

            case 1:    //Put the transmitting machin id after checking the data
                if((data == robotParamData.nIDMDUI) || (data == robotParamData.nIDMDT))
                {
                    byChkSum += data;
                    serial_comm_rcv_buff[byPacketNum++] = data;

                    rcv_step++;
                }
                else
                {
                    rcv_step = 0;
                    byPacketNum = 0;
#if (ENABLE_SERIAL_DEBUG == 1)                    
                    ROS_INFO("error.ser: %s, %d", __FILE__, __LINE__);
#endif
                }
                break;

            case 2:    //Check ID
                if(data == robotParamData.nid|| data == robotParamData.nid2 ||data == ID_ALL )
                {
                    byChkSum += data;
                    serial_comm_rcv_buff[byPacketNum++] = data;

                    rcv_step++;
                }
                else
                {
                    rcv_step = 0;
                    byPacketNum = 0;
#if (ENABLE_SERIAL_DEBUG == 1)                    
                    ROS_INFO("error.ser: %s, %d", __FILE__, __LINE__);
#endif
                }
                break;

             case 3:    //Put the PID number into the array
                byChkSum += data;
                serial_comm_rcv_buff[byPacketNum++] = data;

                rcv_step++;
                break;

             case 4:    //Put the DATANUM into the array
                byChkSum += data;
                serial_comm_rcv_buff[byPacketNum++] = data;

                byMaxDataNum = data;
                byDataNum = 0;

                rcv_step++;
                break;

             case 5:    //Put the DATA into the array
                byChkSum += data;
                serial_comm_rcv_buff[byPacketNum++] = data;

                if(++byDataNum >= MAX_DATA_SIZE)
                {
                    rcv_step = 0;
#if (ENABLE_SERIAL_DEBUG == 1)                    
                    ROS_INFO("error.ser: %s, %d", __FILE__, __LINE__);
#endif
                    break;
                }

                if(byDataNum >= byMaxDataNum) {
                    rcv_step++;
                }
                break;

             case 6:    //Put the check sum after Checking checksum
                byChkSum += data;
                serial_comm_rcv_buff[byPacketNum++] = data;

                if(byChkSum == 0)
                {
#if (ENABLE_SERIAL_DEBUG == 1)
                    printf("\r\n");
#endif
                    MdReceiveProc();                                 //save the identified serial data to defined variable
                }
                else {
                    ROS_INFO("Error.Checksum");
                }

                byPacketNum = 0;

                rcv_step = 0;
                break;

            default:
                rcv_step = 0;
                break;
        }
    }
    return 1;
}

int ReceiveSerialData(void) //Analyze the communication data
{
    uint8_t byRcvBuf[250];
    uint8_t byBufNumber;

    static uint8_t tempBuffer[250];
    static uint8_t tempLength;

    byBufNumber = ser.available();
    if(byBufNumber != 0)
    {
        if(byBufNumber > sizeof(byRcvBuf)) {
            byBufNumber = sizeof(byRcvBuf);
        }

        ser.read(byRcvBuf, byBufNumber);

        memcpy(tempBuffer, byRcvBuf, byBufNumber);
        tempLength = byBufNumber;

        AnalyzeReceivedData(tempBuffer, tempLength);
    }

    return 1;
}

/////////////// the end of file